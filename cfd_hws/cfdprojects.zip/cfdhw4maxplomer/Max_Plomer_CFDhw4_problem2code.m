clc;clear;

%constant parameters
ap=.7;%relaxation
au=.7;%relaxation
den=1;
A_A=3;
A_B=1;
p_1=28;
p_3=0;

%Initial Guess
u_A=5/3;
u_B=5;
p_2_star=25;

iteration=0;
while 1
    iteration=iteration+1;
    %solve momentume equations for u_b_star and u_c_star

    u_A_star=(p_1 - p_2_star)/(den*u_A);

    u_B_star=(A_B^2*(p_2_star - p_3)+(den*u_A*A_A*u_A_star*A_A))/(den*u_B*A_B*A_B);

    %solve the p' equation for pressure correction

    p_2_corr=(u_A_star*A_A - u_B_star*A_B)/(A_B/(den*u_B) -  (den*u_A*A_A*A_A)/(den*u_A*den*u_B*A_B)   +  A_A/(den*u_A) );

    %calculate p

    p_2=ap*p_2_corr+p_2_star;

    %calculate u

    u_A=au*(u_A_star-p_2_corr/(den*u_A)) + (1-au)*u_A;
    u_B=au*(u_B_star+(A_B^2*p_2_corr+den*u_A*A_A*(-p_2_corr/(den*u_A))*A_A)/(den*u_B*A_B*A_B)) + (1-au)*u_B;

    
    %convergence criteria
    if abs(p_2-p_2_star)<.001
        break;
    end
    
    %update p_2star
    p_2_star=p_2;
    
    
end
%answers
iteration %10
u_A %5.2915
u_B %15.8745
p_2 %1.4762e-04

