clc;clear;

%constant parameters
ap=.7;%relaxation
au=.7;%relaxation
dx=2;
c_b=.25;
c_c=.2;
A_b=5;
A_c=4;
p_1=200;
p_3=38;

%Initial Guess
u_b=15;% this is u_(i)
u_c=15;% this is u_(i+1)
p_2_star=120;

iteration=0;
while 1
    iteration=iteration+1;
    %solve momentume equations for u_b_star and u_c_star

    u_b_star=(p_1 - p_2_star)/(c_b*u_b*dx);

    u_c_star=(p_2_star - p_3)/(c_c*u_c*dx);

    %solve the p' equation for pressure correction

    p_2_corr=(u_b_star*A_b - u_c_star*A_c)/(A_c/(dx*c_c*u_c)  +  A_b/(dx*c_b*u_b) );

    %calculate p

    p_2=ap*p_2_corr+p_2_star;

    %calculate u

    u_b=au*(u_b_star-p_2_corr/(c_b*u_b*dx)) + (1-au)*u_b;
    u_c=au*(u_c_star+p_2_corr/(c_c*u_c*dx)) + (1-au)*u_c;

    
    %convergence criteria
    if abs(p_2-p_2_star)<.001
        break;
    end
    
    %update p_2star
    p_2_star=p_2;
    
    
end
%answers
iteration %11
u_b %12.0000
u_c %14.9999
p_2 %127.9995

