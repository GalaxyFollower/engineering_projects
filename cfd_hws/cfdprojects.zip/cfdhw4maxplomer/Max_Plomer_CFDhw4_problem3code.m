clc;clear;

p1=275;
p2=270;
p4=0;
p5=40;

Qf=20;
%ap=.7%pressure relaxation
Ca=.4;
Cb=.2;
Cd=.2;
Cf=.2;
Cc=.1;
Ce=.1;

%guess p3 and p6
p3_star=140;
p6_star=90;

%obtain Q star values
Qa_star=Ca*(p1-p3_star);
Qb_star=Cb*(p3_star-p2);
Qc_star=Cc*(p4-p3_star);
Qd_star=Cd*(p3_star-p6_star);
Qe_star=Ce*(p5-p6_star);

%matrix of p3' p6'
A=[(Ca+Cb+Cc+Cd) -(Cd);
    -(Cd) (Cd+Ce)];

%RHS

C=[(-Cb*(p3_star-p2)+Cc*(p4-p3_star)-Cd*(p3_star-p6_star)+Ca*(p1-p3_star));
   (Ce*(p5-p6_star)+Cd*(p3_star-p6_star))]; 


B=linsolve(A,C);
p3_corr=B(1);
p6_corr=B(2);


%correct the guessed pressure and Q* values
p3=p3_star+p3_corr;
p6=p6_star+p6_corr;

Qa=Qa_star*-p3_corr;
Qb=Qb_star*p3_corr;
Qc=Qc_star*-p3_corr;
Qd=Qd_star*p3_corr;
Qe=Qe_star*-p6_corr;


%answers
p3%217.3913
p6%158.2609
Qa%-4.1791e+03
Qb%-2.0122e+03
Qc%1.0835e+03
Qd%773.9130
Qe%341.3043
