function CFDhw3code()
    clc;
    clear;

    %Parameters
    U=.05;%m/s
    T1=300;%Kelvin
    q3=10*1000;%W/m^2
    L1=0.5;%m
    L2=0.05;%m
    k=10;%W/(m*K)
    cp=4187;%J/kg-K
    d=1000;%kg/m^3

    mesh_ht=6; %height
    mesh_wd=12; %width
    
    dy=L2/mesh_ht;
    dx=L1/mesh_wd;
    %matrix of coeffients of cell temperatures
    A=zeros(mesh_ht*mesh_wd,mesh_ht*mesh_wd);
    %Vector for right hand side of my equations
    C=zeros(mesh_ht*mesh_wd,1);
    %calls function that assigns coefficients to the matrix
    creatematrix();

    
    
    %save size of matrix to file
    fid = fopen('sizeofmatrix.txt', 'wt');
    
    fprintf(fid, '%d\n', (mesh_ht*mesh_wd));
            
    fclose(fid);
    
    
    %save A to file
    fid = fopen('matrix.txt', 'wt');
    for k=1:(mesh_ht*mesh_wd)
        for l=1:(mesh_ht*mesh_wd)
            fprintf(fid, '%.6f\n', A(k,l));
        end
    end    
    fclose(fid);
    
    %save C to file
    fid = fopen('RHS.txt', 'wt');
    for k=1:(mesh_ht*mesh_wd)
        
            fprintf(fid, '%.6f\n', C(k));
       
    end    
    fclose(fid);
    
    
    
    %This function goes through different cell types 
    function creatematrix()
        %interior cells
        for i=2:(mesh_wd-1)
            for j=2:(mesh_ht-1)
                interior_cell(i,j);
            end   
        end
        %Bottom boundary cells
        j=1;
        for i=2:(mesh_wd-1)
            bottom_cell(i,j);
        end
        %Top boundary cells
        j=mesh_ht;
        for i=2:(mesh_wd-1)
            top_cell(i,j);
        end
        %Left boundary cells
        i=1;
        for j=2:(mesh_ht-1)
            left_cell(i,j);
        end
        %Right boundary cells
        i=mesh_wd;
        for j=2:(mesh_ht-1)
            right_cell(i,j);
        end
        %Top-Left corner
        top_left_cell(1,mesh_ht);
        %Top-Right corner
        top_right_cell(mesh_wd,mesh_ht);
        %Bottom-Right corner
        bottom_right_cell(mesh_wd,1);
        %Bottom-Left corner
        bottom_left_cell(1,1); 
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This series of functions contains the coefficents from the derived
%equations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function interior_cell(i,j)
        %i-1,j: W
        A(cellnum(i,j),cellnum((i-1),j))=-(dy/dx+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k); %note: u(j)=(1/(2*mesh_ht)+(j-1)/mesh_ht)*U
        %i+1,k: E
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j: P
        A(cellnum(i,j),cellnum(i,j))=(2*dy/dx+2*dx/dy+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i,j-1: S
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1: N
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=0;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Boundary cells
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function bottom_cell(i,j)
        %i-1,j: W
        A(cellnum(i,j),cellnum((i-1),j))=-(dy/dx+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i+1,j: E
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j: P
        A(cellnum(i,j),cellnum(i,j))=(2*dy/dx+dx/dy+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i,j-1: S (no cell)
        
        %i,j+1: N
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=q3*dx/k; 
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function top_cell(i,j)
        %i-1,j: W
        A(cellnum(i,j),cellnum((i-1),j))=-(dy/dx+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i+1,j: E
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j: P
        A(cellnum(i,j),cellnum(i,j))=(2*dy/dx+3*dx/dy+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i,j-1: S
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1: N (no cell)
        
        %RHS
        C(cellnum(i,j),1)=2*T1*dx/dy;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function left_cell(i,j)
        %i-1,j: W (no cell)
        
        %i+1,j: E
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j: P
        A(cellnum(i,j),cellnum(i,j))=(3*dy/dx+2*dx/dy+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i,j-1: S
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1: N
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=T1*(2*dy/dx+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function right_cell(i,j)
        %i-1,j: W
        A(cellnum(i,j),cellnum((i-1),j))=-(dy/dx+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i+1,j: E (no cell)
        
        %i,j: P
        A(cellnum(i,j),cellnum(i,j))=(dy/dx+2*dx/dy+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i,j-1: S
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1: N
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=0;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Corner cells
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function top_left_cell(i,j)
        %i-1,j: W (no cell)
        
        %i+1,j: E
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j: P
        A(cellnum(i,j),cellnum(i,j))=(3*dy/dx+3*dx/dy+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i,j-1: S
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1: N (no cell)
        
        %RHS
        C(cellnum(i,j),1)=T1*(2*dy/dx+2*dx/dy+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function top_right_cell(i,j)
        %i-1,j: W
        A(cellnum(i,j),cellnum((i-1),j))=-(dy/dx+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i+1,j: E (no cell)
        
        %i,j: P
        A(cellnum(i,j),cellnum(i,j))=(dy/dx+3*dx/dy+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i,j-1: S
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1: N (no cell)
        
        %RHS
        C(cellnum(i,j),1)=2*T1*dx/dy;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function bottom_right_cell(i,j)
        %i-1,j: W
        A(cellnum(i,j),cellnum((i-1),j))=-(dy/dx+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i+1,j: E (no cell)
        
        %i,j: P
        A(cellnum(i,j),cellnum(i,j))=(dy/dx+dx/dy+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i,j-1: S (no cell)
        
        %i,j+1: N
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=q3*dx/k;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function bottom_left_cell(i,j)
        %i-1,j: W (no cell)
        
        %i+1,j: E
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j: P
        A(cellnum(i,j),cellnum(i,j))=(3*dy/dx+dx/dy+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k);
        %i,j-1: S (no cell)
        
        %i,j+1: N
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=T1*(2*dy/dx+d*cp*(1/(2*mesh_ht)+(j-1)/mesh_ht)*U*dy/k)+q3*dx/k;
    end
    %This function reads in the cell address (i,j) and outputs a cell #
    function [cell]=cellnum(i,j)
      cell=(i-1)*mesh_ht+j;

    end


end