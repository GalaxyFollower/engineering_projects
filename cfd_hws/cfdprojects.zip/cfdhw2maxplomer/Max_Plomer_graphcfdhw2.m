
function graphcfdhw2()
clc;clear;
    [A] = textread('6_by_12.txt', '%f');%low res mesh
    [B] = textread('12_by_24.txt', '%f');%high res mesh
    %mesh parameters
    mesh_ht_hires=12;
    mesh_wd_hires=24;
    mesh_ht_lowres=6;
    mesh_wd_lowres=12;
    %Put vectors of temperatures into matricies
    for i=1:mesh_wd_hires
        for j=1:mesh_ht_hires
            matrix_hires(j,i)=B(cellhinum(i,j));
        end
    end
    
    for i=1:mesh_wd_lowres
        for j=1:mesh_ht_lowres
            matrix_lowres(j,i)=A(celllownum(i,j));
        end
    end
    
    %calculating delta x/y and scales for the graph
    L1=0.2;%m
    L2=0.1;%m
    
    dx_hires=L1/mesh_wd_hires;
    dy_hires=L2/mesh_ht_hires;
    
    dx_lowres=L1/mesh_wd_lowres;
    dy_lowres=L2/mesh_ht_lowres;
    
    %wrong scale
    x_hires=(dx_hires/2):dx_hires:(L1-dx_hires/2);
    y_hires=(dy_hires/2):dy_hires:(L2-dy_hires/2);
    x_lowres=(dx_lowres/2):dx_lowres:(L1-dx_lowres/2);
    y_lowres=(dy_lowres/2):dy_lowres:(L2-dy_lowres/2);
    
    %prints both matricies to the same graph
    figure(1)
    
    mesh(x_hires,y_hires,matrix_hires)
    
    hold on
    
    mesh(x_lowres,y_lowres,matrix_lowres)
    
    hold off
    
    

    
    %inputs cell address outputs cell #
    function [cell]=cellhinum(i,j)
      cell=(i-1)*mesh_ht_hires+j;

    end
    function [cell]=celllownum(i,j)
      cell=(i-1)*mesh_ht_lowres+j;

    end

end