function CFDhw2m()
    clc;
    clear;

    %Parameters
    T1=350;%Kelvin
    q3=-50*1000;%W/m^2
    h=15;%W/(m^2*K)
    Tinf=300;%Kelvin
    L1=0.2;%m
    L2=0.1;%m
    k=100;%W/(m*K)

    mesh_ht=12; %height
    mesh_wd=24; %width
    
    dy=L2/mesh_ht;
    dx=L1/mesh_wd;
    %matrix of coeffients of cell temperatures
    A=zeros(mesh_ht*mesh_wd,mesh_ht*mesh_wd);
    %Vector for right hand side of my equations
    C=zeros(mesh_ht*mesh_wd,1);
    %calls function that assigns coefficients to the matrix
    creatematrix();

    B=linsolve(A,C);
    
    %save B to file
    fid = fopen('12_by_24.txt', 'wt');
    for k=1:length(B)
        fprintf(fid, '%.6f\n', B(k));
    end
    fclose(fid);
    %This function goes through different cell types 
    function creatematrix()
        %interior cells
        for i=2:(mesh_wd-1)
            for j=2:(mesh_ht-1)
                interior_cell(i,j);
            end   
        end
        %Bottom boundary cells
        j=1;
        for i=2:(mesh_wd-1)
            bottom_cell(i,j);
        end
        %Top boundary cells
        j=mesh_ht;
        for i=2:(mesh_wd-1)
            top_cell(i,j);
        end
        %Left boundary cells
        i=1;
        for j=2:(mesh_ht-1)
            left_cell(i,j);
        end
        %Right boundary cells
        i=mesh_wd;
        for j=2:(mesh_ht-1)
            right_cell(i,j);
        end
        %Top-Left corner
        top_left_cell(1,mesh_ht);
        %Top-Right corner
        top_right_cell(mesh_wd,mesh_ht);
        %Bottom-Right corner
        bottom_right_cell(mesh_wd,1);
        %Bottom-Left corner
        bottom_left_cell(1,1); 
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This series of functions contains the coefficents from the derived
%equations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function interior_cell(i,j)
        %i-1,j
        A(cellnum(i,j),cellnum((i-1),j))=-dy/dx;
        %i+1,j
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j
        A(cellnum(i,j),cellnum(i,j))=(2*dy/dx+2*dx/dy);
        %i,j-1
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=0;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Boundary cells
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function bottom_cell(i,j)
        %i-1,j
        A(cellnum(i,j),cellnum((i-1),j))=-dy/dx;
        %i+1,j
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j
        A(cellnum(i,j),cellnum(i,j))=(2*dy/dx+dx/dy);
        %i,j-1 (no cell)
        
        %i,j+1
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=q3*dx/k; 
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function top_cell(i,j)
        %i-1,j
        A(cellnum(i,j),cellnum((i-1),j))=-dy/dx;
        %i+1,j
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j
        A(cellnum(i,j),cellnum(i,j))=(2*dy/dx+3*dx/dy);
        %i,j-1
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1 (no cell)
        
        %RHS
        C(cellnum(i,j),1)=2*T1*dx/dy;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function left_cell(i,j)
        %i-1,j (no cell)
        
        %i+1,j
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j
        A(cellnum(i,j),cellnum(i,j))=((3-2*k/(k+h*dx/2))*dy/dx+2*dx/dy);
        %i,j-1
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=(h*dy/(k+h*dx/2))*Tinf;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function right_cell(i,j)
        %i-1,j
        A(cellnum(i,j),cellnum((i-1),j))=-dy/dx;
        %i+1,j (no cell)
        
        %i,j
        A(cellnum(i,j),cellnum(i,j))=(3*dy/dx+2*dx/dy);
        %i,j-1
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=2*T1*dy/dx;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Corner cells
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function top_left_cell(i,j)
        %i-1,j (no cell)
        
        %i+1,j
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j
        A(cellnum(i,j),cellnum(i,j))=((3-2*k/(k+h*dx/2))*dy/dx+3*dx/dy);
        %i,j-1
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1 (no cell)
        
        %RHS
        C(cellnum(i,j),1)=(h*dy/(k+h*dx/2))*Tinf+2*T1*dx/dy;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function top_right_cell(i,j)
        %i-1,j
        A(cellnum(i,j),cellnum((i-1),j))=-dy/dx;
        %i+1,j (no cell)
        
        %i,j
        A(cellnum(i,j),cellnum(i,j))=(3*dy/dx+3*dx/dy);
        %i,j-1
        A(cellnum(i,j),cellnum(i,(j-1)))=-dx/dy;
        %i,j+1 (no cell)
        
        %RHS
        C(cellnum(i,j),1)=T1*(2*dy/dx+2*dx/dy);
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function bottom_right_cell(i,j)
        %i-1,j
        A(cellnum(i,j),cellnum((i-1),j))=-dy/dx;
        %i+1,j (no cell)
        
        %i,j
        A(cellnum(i,j),cellnum(i,j))=(3*dy/dx+dx/dy);
        %i,j-1 (no cell)
        
        %i,j+1
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=2*T1*dy/dx+q3*dx/k;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function bottom_left_cell(i,j)
        %i-1,j (no cell)
        
        %i+1,j
        A(cellnum(i,j),cellnum((i+1),j))=-dy/dx;
        %i,j
        A(cellnum(i,j),cellnum(i,j))=((3-2*k/(k+h*dx/2))*dy/dx+dx/dy);
        %i,j-1 (no cell)
        
        %i,j+1
        A(cellnum(i,j),cellnum(i,(j+1)))=-dx/dy;
        %RHS
        C(cellnum(i,j),1)=(h*dy/(k+h*dx/2))*Tinf+q3*dx/k;
    end
    %This function reads in the cell address (i,j) and outputs a cell #
    function [cell]=cellnum(i,j)
      cell=(i-1)*mesh_ht+j;

    end


end